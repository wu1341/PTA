import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import platform
import os
from PIL import Image, ImageDraw, ImageFont, ImageTk
import requests
import json
import threading

class TextAnalyzerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("诗歌AI分析工具")
        self.root.geometry("1537x768")
        
        # 初始化变量
        self.bg_image = None
        self.bg_width = 1537
        self.bg_height = 768
        self.file_content = ""
        self.bg_photo = None
        self.main_canvas = None
        self.analyze_button = None
        
        # 尝试加载背景图（可选）
        self.load_background_image()
        
        # 创建主界面
        self.create_main_interface()

    def load_background_image(self):
        """加载背景图片（可选）"""
        try:
            # 可替换为自定义背景图路径
            bg_path = "2.jpg"
            if os.path.exists(bg_path):
                self.bg_image = Image.open(bg_path)
                self.bg_width, self.bg_height = self.bg_image.size
        except:
            self.bg_image = None

    def get_chinese_font(self, size):
        """获取系统中可用的中文字体"""
        system = platform.system()
        fonts = []
        
        if system == "Windows":
            fonts = [
                "C:/Windows/Fonts/simhei.ttf",
                "C:/Windows/Fonts/simsun.ttc",
                "C:/Windows/Fonts/msyh.ttc",
                "C:/Windows/Fonts/arial.ttf",
            ]
        elif system == "Darwin":
            fonts = [
                "/System/Library/Fonts/PingFang.ttc",
                "/System/Library/Fonts/Helvetica.ttc",
                "/System/Library/Fonts/Menlo.ttc",
            ]
        else:
            fonts = [
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
                "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
            ]
        
        for font_path in fonts:
            if os.path.exists(font_path):
                try:
                    return ImageFont.truetype(font_path, size)
                except:
                    continue
        
        return ImageFont.load_default()

    def create_main_interface(self):
        for widget in self.root.winfo_children():
            widget.destroy()

        self.main_canvas = tk.Canvas(self.root)
        self.main_canvas.pack(fill=tk.BOTH, expand=True)

        self.root.update_idletasks()
        canvas_w = self.main_canvas.winfo_width() or self.bg_width
        canvas_h = self.main_canvas.winfo_height() or self.bg_height

        if self.bg_image:
            img_ratio = self.bg_image.width / self.bg_image.height
            canvas_ratio = canvas_w / canvas_h

            if img_ratio > canvas_ratio:
                new_w = canvas_w
                new_h = int(canvas_w / img_ratio)
            else:
                new_h = canvas_h
                new_w = int(canvas_h * img_ratio)

            if new_w <= 0 or new_h <= 0:
                new_w, new_h = canvas_w, canvas_h

            img_resized = self.bg_image.resize((new_w, new_h), 
                                              getattr(Image, 'Resampling', Image).LANCZOS 
                                              if hasattr(Image, 'Resampling') else Image.ANTIALIAS)
            
            bg_img = Image.new("RGB", (canvas_w, canvas_h), "#FFE57F")
            paste_x = max(0, (canvas_w - new_w) // 2)
            paste_y = max(0, (canvas_h - new_h) // 2)
            bg_img.paste(img_resized, (paste_x, paste_y))
            
            text_layer = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(text_layer)
            
            title_font = self.get_chinese_font(28)  # 增大标题字体
            topic_font = self.get_chinese_font(16)  # 题目字体
            
            # 标题文字
            title_text = "诗歌AI分析工具"
            title_bbox = draw.textbbox((0, 0), title_text, font=title_font)
            title_w = title_bbox[2] - title_bbox[0]
            title_pos = (canvas_w // 2 - title_w // 2, 30 - 12)
            draw.text(title_pos, title_text, font=title_font, fill=(255, 255, 0, 204))  # 黄色文字
            
            # 题目说明文字（删除学号姓名后调整起始位置）
            topic_text = """题目：诗歌AI分析
（1）打开txt文件，为诗歌；
（2）调用本地AI（LM Studio）直接分析诗歌内容；
（3）界面上显示AI的分析结果"""
            lines = topic_text.split('\n')
            line_height = 28  # 增大行距
            start_y = 80      # 删除学号姓名后调整起始位置
            for i, line in enumerate(lines):
                if line.strip():
                    line_bbox = draw.textbbox((0, 0), line, font=topic_font)
                    line_w = line_bbox[2] - line_bbox[0]
                    line_pos = (canvas_w // 2 - line_w // 2, start_y + i * line_height)
                    draw.text(line_pos, line, font=topic_font, fill=(255, 255, 0, 204))  # 黄色文字
            
            bg_img_rgba = bg_img.convert("RGBA")
            final_img = Image.alpha_composite(bg_img_rgba, text_layer)
            self.bg_photo = ImageTk.PhotoImage(final_img)
            self.main_canvas.create_image(0, 0, anchor=tk.NW, image=self.bg_photo)
        else:
            self.main_canvas.create_rectangle(0, 0, canvas_w, canvas_h, fill="#FFE57F", outline="")

            # 标题标签
            title_label = tk.Label(
                self.root,
                text="诗歌AI分析工具",
                font=("Arial", 28, "bold"),
                bg="#FFE57F",
                fg="yellow",  # 黄色文字
                relief="flat",
                padx=10,
                pady=5
            )
            self.main_canvas.create_window(canvas_w // 2, 30, window=title_label)

            # 题目说明文字（删除学号姓名后调整位置）
            topic_text = """题目：诗歌AI分析
（1）打开txt文件，为诗歌；
（2）调用本地AI（LM Studio）直接分析诗歌内容；
（3）界面上显示AI的分析结果"""
            topic_label = tk.Text(
                self.root,
                width=40,
                height=6,
                font=("Arial", 16),
                bg="#FFE57F",
                fg="yellow",  # 黄色文字
                wrap=tk.WORD,
                bd=0,
                relief="flat"
            )
            topic_label.insert(tk.END, topic_text)
            topic_label.config(state=tk.DISABLED)
            self.main_canvas.create_window(canvas_w // 2, 120, window=topic_label)

        # 进入分析界面按钮
        self.analyze_button = tk.Button(
            self.root,
            text="进入AI分析界面",
            font=("Arial", 16, "bold"),
            bg="#4CAF50",
            fg="white",
            activebackground="#45a049",
            padx=20,
            pady=12,
            command=self.create_analysis_interface
        )
        self.main_canvas.create_window(canvas_w // 2, canvas_h - 80, window=self.analyze_button)

        def on_resize(event):
            if event.widget == self.root:
                if hasattr(self, 'analyze_button'):
                    self.root.after_idle(self.redraw_main_interface)

        self.root.bind("<Configure>", on_resize)

    def redraw_main_interface(self):
        if not hasattr(self, 'analyze_button') or self.analyze_button.winfo_exists() == 0:
            return

        self.root.update_idletasks()
        canvas_w = self.main_canvas.winfo_width() or self.bg_width
        canvas_h = self.main_canvas.winfo_height() or self.bg_height

        self.main_canvas.delete("all")

        if self.bg_image:
            img_ratio = self.bg_image.width / self.bg_image.height
            canvas_ratio = canvas_w / canvas_h

            if img_ratio > canvas_ratio:
                new_w = canvas_w
                new_h = int(canvas_w / img_ratio)
            else:
                new_h = canvas_h
                new_w = int(canvas_h * img_ratio)

            if new_w <= 0 or new_h <= 0:
                new_w, new_h = canvas_w, canvas_h

            img_resized = self.bg_image.resize((new_w, new_h), 
                                              getattr(Image, 'Resampling', Image).LANCZOS 
                                              if hasattr(Image, 'Resampling') else Image.ANTIALIAS)
            
            bg_img = Image.new("RGB", (canvas_w, canvas_h), "#FFE57F")
            paste_x = max(0, (canvas_w - new_w) // 2)
            paste_y = max(0, (canvas_h - new_h) // 2)
            bg_img.paste(img_resized, (paste_x, paste_y))
            
            text_layer = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(text_layer)
            
            title_font = self.get_chinese_font(28)  # 增大标题字体
            topic_font = self.get_chinese_font(16)  # 题目字体
            
            # 标题文字
            title_text = "诗歌AI分析工具"
            title_bbox = draw.textbbox((0, 0), title_text, font=title_font)
            title_w = title_bbox[2] - title_bbox[0]
            title_pos = (canvas_w // 2 - title_w // 2, 30 - 12)
            draw.text(title_pos, title_text, font=title_font, fill=(255, 255, 0, 204))  # 黄色文字
            
            # 题目说明文字（删除学号姓名后调整起始位置）
            topic_text = """题目：诗歌AI分析
（1）打开txt文件，为诗歌；
（2）调用本地AI（LM Studio）直接分析诗歌内容；
（3）界面上显示AI的分析结果"""
            lines = topic_text.split('\n')
            line_height = 28  # 增大行距
            start_y = 80      # 删除学号姓名后调整起始位置
            for i, line in enumerate(lines):
                if line.strip():
                    line_bbox = draw.textbbox((0, 0), line, font=topic_font)
                    line_w = line_bbox[2] - line_bbox[0]
                    line_pos = (canvas_w // 2 - line_w // 2, start_y + i * line_height)
                    draw.text(line_pos, line, font=topic_font, fill=(255, 255, 0, 204))  # 黄色文字
            
            bg_img_rgba = bg_img.convert("RGBA")
            final_img = Image.alpha_composite(bg_img_rgba, text_layer)
            self.bg_photo = ImageTk.PhotoImage(final_img)
            self.main_canvas.create_image(0, 0, anchor=tk.NW, image=self.bg_photo)
        else:
            self.main_canvas.create_rectangle(0, 0, canvas_w, canvas_h, fill="#FFE57F", outline="")

            # 标题标签
            title_label = tk.Label(
                self.root,
                text="诗歌AI分析工具",
                font=("Arial", 28, "bold"),
                bg="#FFE57F",
                fg="yellow",  # 黄色文字
                relief="flat",
                padx=10,
                pady=5
            )
            self.main_canvas.create_window(canvas_w // 2, 30, window=title_label)

            # 题目说明文字（删除学号姓名后调整位置）
            topic_text = """题目：诗歌AI分析
（1）打开txt文件，为诗歌；
（2）调用本地AI（LM Studio）直接分析诗歌内容；
（3）界面上显示AI的分析结果"""
            topic_label = tk.Text(
                self.root,
                width=40,
                height=6,
                font=("Arial", 16),
                bg="#FFE57F",
                fg="yellow",  # 黄色文字
                wrap=tk.WORD,
                bd=0,
                relief="flat"
            )
            topic_label.insert(tk.END, topic_text)
            topic_label.config(state=tk.DISABLED)
            self.main_canvas.create_window(canvas_w // 2, 120, window=topic_label)

        self.main_canvas.create_window(canvas_w // 2, canvas_h - 80, window=self.analyze_button)

    def create_analysis_interface(self):
        for widget in self.root.winfo_children():
            widget.destroy()

        self.analysis_frame = ttk.Frame(self.root)
        self.analysis_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        control_frame = ttk.Frame(self.analysis_frame)
        control_frame.pack(fill=tk.X, pady=5)

        file_button = ttk.Button(control_frame, text="选择诗歌TXT文件", command=self.load_file)
        file_button.pack(side=tk.LEFT, padx=5)

        # 禁用分析按钮直到加载文件
        self.analyze_ai_button = ttk.Button(control_frame, text="AI分析诗歌", command=self.start_ai_analysis, state=tk.DISABLED)
        self.analyze_ai_button.pack(side=tk.LEFT, padx=5)

        back_button = ttk.Button(control_frame, text="返回主界面", command=self.return_to_main)
        back_button.pack(side=tk.RIGHT, padx=5)

        # 创建内容区域
        content_frame = ttk.Frame(self.analysis_frame)
        content_frame.pack(fill=tk.BOTH, expand=True, pady=5)

        # 左侧：文件内容
        left_frame = ttk.Frame(content_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 5))

        left_label = ttk.Label(left_frame, text="诗歌内容:")
        left_label.pack(anchor=tk.W)

        self.content_text = tk.Text(left_frame, wrap=tk.WORD, font=("Arial", 12))
        scrollbar_y = ttk.Scrollbar(left_frame, orient=tk.VERTICAL, command=self.content_text.yview)
        self.content_text.configure(yscrollcommand=scrollbar_y.set)
        self.content_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar_y.pack(side=tk.RIGHT, fill=tk.Y)

        # 右侧：AI分析结果
        right_frame = ttk.Frame(content_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=(5, 0))

        right_label = ttk.Label(right_frame, text="AI分析结果:")
        right_label.pack(anchor=tk.W)

        self.result_text = tk.Text(right_frame, wrap=tk.WORD, font=("Arial", 12))
        scrollbar_result = ttk.Scrollbar(right_frame, orient=tk.VERTICAL, command=self.result_text.yview)
        self.result_text.configure(yscrollcommand=scrollbar_result.set)
        self.result_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar_result.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 状态标签
        self.status_label = ttk.Label(control_frame, text="状态：未加载文件", foreground="gray")
        self.status_label.pack(side=tk.LEFT, padx=20)

    def load_file(self):
        file_path = filedialog.askopenfilename(
            title="选择诗歌TXT文件",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if file_path:
            encodings = ['utf-8', 'gbk', 'gb2312', 'utf-16']
            content = None
            
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    break
                except UnicodeDecodeError:
                    continue
            
            if content is not None:
                self.file_content = content
                self.content_text.delete(1.0, tk.END)
                self.content_text.insert(tk.END, self.file_content)
                
                # 启用分析按钮
                self.analyze_ai_button.config(state=tk.NORMAL)
                self.status_label.config(text=f"状态：已加载文件 - {os.path.basename(file_path)}", foreground="green")
                messagebox.showinfo("成功", f"文件加载成功！共{len(self.file_content)}个字符")
            else:
                messagebox.showwarning(
                    "编码格式错误", 
                    "检测到该文件不是UTF-8、GBK、GB2312或UTF-16编码！\n\n请将文件另存为或转换为 UTF-8 编码后重新打开。"
                )
                self.file_content = ""
                self.content_text.delete(1.0, tk.END)
                self.analyze_ai_button.config(state=tk.DISABLED)
                self.status_label.config(text="状态：编码错误 - 请重新选择文件", foreground="red")

    def start_ai_analysis(self):
        if not self.file_content:
            messagebox.showwarning("警告", "请先加载诗歌文件")
            return
        
        # 禁用分析按钮防止重复点击
        self.analyze_ai_button.config(state=tk.DISABLED)
        self.status_label.config(text="状态：正在分析诗歌...", foreground="blue")
        
        # 清空之前的结果
        self.result_text.delete(1.0, tk.END)
        self.result_text.insert(tk.END, "🔍 正在连接本地AI并分析诗歌，请稍候...\n\n")
        
        # 在新线程中执行AI分析，防止界面冻结
        thread = threading.Thread(target=self.perform_ai_analysis)
        thread.daemon = True
        thread.start()

    def perform_ai_analysis(self):
        try:
            # 调用LM Studio API - 启用流式响应
            url = "http://localhost:1234/v1/chat/completions"
            headers = {
                "Content-Type": "application/json; charset=utf-8"
            }
            
            # 构建提示词
            system_prompt = "你是一位精通中国古典文学与现代诗歌的AI评论家。请对用户提供的诗歌进行深度赏析，包括但不限于：1. 意象与意境分析 2. 情感基调与主题思想 3. 艺术手法与修辞特色 4. 总体评价。请使用utf-8格式输出，语言优美、专业、流畅。"
            user_prompt = f"请赏析以下诗歌：\n\n{self.file_content}"
            
            data = {
                "model": "local-model",
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                "temperature": 0.7,
                "max_tokens": 2048,
                "stream": True,  # 启用流式响应
                "stream_options": {"include_usage": True}  # 包含使用情况
            }
            
            # 发送流式请求
            response = requests.post(
                url, 
                headers=headers, 
                json=data, 
                stream=True, 
                timeout=600  # 进一步延长超时时间
            )
            response.raise_for_status()
            
            # 设置响应编码为utf-8
            response.encoding = 'utf-8'
            
            # 实时处理流式响应（逐字/逐段输出）
            self.root.after(0, lambda: self.result_text.delete(1.0, tk.END))
            full_response = ""  # 存储完整响应内容
            
            for line in response.iter_lines(decode_unicode=True, chunk_size=8192):  # 增大chunk_size
                if line.startswith("data: "):
                    json_str = line[6:].strip()
                    if json_str == "[DONE]":
                        break
                    if not json_str:
                        continue
                    
                    try:
                        chunk = json.loads(json_str)
                        
                        # 检查是否有usage信息
                        if 'usage' in chunk:
                            # usage信息不需要显示给用户
                            continue
                        
                        choices = chunk.get('choices', [])
                        if choices and len(choices) > 0:
                            delta = choices[0].get('delta', {})
                            content = delta.get('content', '')
                            
                            if content:
                                # 确保内容是正确的字符串格式
                                content = content.encode().decode('utf-8', errors='ignore')
                                full_response += content
                                
                                # 实时更新UI，每次收到内容都立即显示
                                self.root.after(0, self.append_ai_result, content)
                                
                    except json.JSONDecodeError as e:
                        # 忽略JSON解码错误
                        continue
                    except Exception as e:
                        # 记录错误但继续处理
                        print(f"处理响应时发生错误: {e}")
                        continue
            
            # 确保所有内容都已写入
            if full_response:
                self.root.after(0, lambda: self.append_ai_result("\n\n✅ AI分析完成！"))
            
            # 分析完成更新状态
            self.root.after(0, lambda: self.status_label.config(text="状态：分析完成", foreground="green"))
            self.root.after(0, lambda: self.analyze_ai_button.config(state=tk.NORMAL))
                
        except requests.exceptions.ConnectionError:
            error_msg = (
                "❌ 无法连接到LM Studio\n\n"
                "请检查以下几点：\n"
                "1. LM Studio是否已启动\n"
                "2. 本地服务器是否已开启（端口1234）\n"
                "3. 是否已加载合适的模型并设置为默认\n"
            )
            self.root.after(0, lambda: self.result_text.delete(1.0, tk.END))
            self.root.after(0, lambda: self.result_text.insert(tk.END, error_msg))
            self.root.after(0, lambda: self.status_label.config(text="状态：连接失败", foreground="red"))
            self.root.after(0, lambda: self.analyze_ai_button.config(state=tk.NORMAL))
            
        except requests.exceptions.Timeout:
            error_msg = "❌ 请求超时\n\nAI分析时间过长，请检查模型响应速度或网络状况。"
            self.root.after(0, lambda: self.result_text.insert(tk.END, error_msg))
            self.root.after(0, lambda: self.status_label.config(text="状态：请求超时", foreground="red"))
            self.root.after(0, lambda: self.analyze_ai_button.config(state=tk.NORMAL))
            
        except Exception as e:
            error_msg = f"❌ AI分析出错: {str(e)}"
            self.root.after(0, lambda: self.result_text.insert(tk.END, error_msg))
            self.root.after(0, lambda: self.status_label.config(text="状态：分析出错", foreground="red"))
            self.root.after(0, lambda: self.analyze_ai_button.config(state=tk.NORMAL))

    def append_ai_result(self, content):
        """追加AI分析结果（流式输出核心函数）"""
        # 确保内容是正确的字符串格式
        content = content.encode().decode('utf-8', errors='ignore')
        self.result_text.insert(tk.END, content)
        # 自动滚动到底部
        self.result_text.see(tk.END)
        # 更新UI
        self.result_text.update_idletasks()

    def return_to_main(self):
        for widget in self.root.winfo_children():
            widget.destroy()
        self.create_main_interface()

if __name__ == "__main__":
    root = tk.Tk()
    app = TextAnalyzerApp(root)
    root.mainloop()
