import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from collections import Counter
import re
import jieba
from wordcloud import WordCloud
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import LatentDirichletAllocation
import matplotlib
matplotlib.use('TkAgg')
import platform
import os
from PIL import Image, ImageTk, ImageDraw, ImageFont


class TextAnalyzerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("文本分析工具")
        
        # 图片尺寸
        self.bg_width, self.bg_height = 600, 944
        
        # 设置窗口大小（初始为图片尺寸），并允许缩放
        self.root.geometry(f"{self.bg_width}x{self.bg_height}+0+0")
        self.root.resizable(True, True)
        
        # 加载背景图片
        self.bg_image = None
        self.bg_photo = None
        self.load_background_image()
        
        # 创建主界面
        self.create_main_interface()
        
        # 初始化变量
        self.file_content = ""
        self.words = []
        self.chars = []

    def load_background_image(self):
        try:
            self.bg_image = Image.open("1.jpg")
            if self.bg_image.size != (self.bg_width, self.bg_height):
                messagebox.showinfo("提示", f"背景图尺寸为 {self.bg_image.size}，将自动缩放至 600x944")
                self.bg_image = self.bg_image.resize((self.bg_width, self.bg_height), Image.Resampling.LANCZOS)
        except FileNotFoundError:
            messagebox.showwarning("警告", "未找到 '1.jpg'！将使用默认黄色背景。")
        except Exception as e:
            messagebox.showerror("错误", f"加载背景图失败：{e}")
            self.bg_image = None

    def get_chinese_font(self, size):
        """获取系统中可用的中文字体"""
        system = platform.system()
        fonts = []
        
        if system == "Windows":
            fonts = [
                "C:/Windows/Fonts/simhei.ttf",
                "C:/Windows/Fonts/simsun.ttc",
                "C:/Windows/Fonts/msyh.ttc",
                "C:/Windows/Fonts/arial.ttf",
            ]
        elif system == "Darwin":
            fonts = [
                "/System/Library/Fonts/PingFang.ttc",
                "/System/Library/Fonts/Helvetica.ttc",
                "/System/Library/Fonts/Menlo.ttc",
            ]
        else:
            fonts = [
                "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
                "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
            ]
        
        for font_path in fonts:
            if os.path.exists(font_path):
                try:
                    return ImageFont.truetype(font_path, size)
                except:
                    continue
        
        return ImageFont.load_default()

    def create_main_interface(self):
        for widget in self.root.winfo_children():
            widget.destroy()

        self.main_canvas = tk.Canvas(self.root)
        self.main_canvas.pack(fill=tk.BOTH, expand=True)

        self.root.update_idletasks()
        canvas_w = self.main_canvas.winfo_width() or self.bg_width
        canvas_h = self.main_canvas.winfo_height() or self.bg_height

        if self.bg_image:
            img_ratio = self.bg_image.width / self.bg_image.height
            canvas_ratio = canvas_w / canvas_h

            if img_ratio > canvas_ratio:
                new_w = canvas_w
                new_h = int(canvas_w / img_ratio)
            else:
                new_h = canvas_h
                new_w = int(canvas_h * img_ratio)

            if new_w <= 0 or new_h <= 0:
                new_w, new_h = canvas_w, canvas_h

            img_resized = self.bg_image.resize((new_w, new_h), 
                                              getattr(Image, 'Resampling', Image).LANCZOS 
                                              if hasattr(Image, 'Resampling') else Image.ANTIALIAS)
            
            bg_img = Image.new("RGB", (canvas_w, canvas_h), "#FFE57F")
            paste_x = max(0, (canvas_w - new_w) // 2)
            paste_y = max(0, (canvas_h - new_h) // 2)
            bg_img.paste(img_resized, (paste_x, paste_y))
            
            text_layer = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(text_layer)
            
            title_font = self.get_chinese_font(24)
            topic_font = self.get_chinese_font(16)
            
            # 绘制标题（居中）
            title_text = "文本分析工具"
            title_bbox = draw.textbbox((0, 0), title_text, font=title_font)
            title_w = title_bbox[2] - title_bbox[0]
            title_pos = (canvas_w // 2 - title_w // 2, 30)
            draw.text(title_pos, title_text, font=title_font, fill=(0, 0, 0, 204))
            
            # 绘制题目说明（居中）
            topic_text = """题目：文本分析
（1）打开txt文件，为诗歌；
（2）对数据进行统计分析，包括词频分析、词云；
（3）界面上设计按钮、标签、文本等控件，单击按钮读取文件、显示内容分析"""
            lines = topic_text.split('\n')
            line_height = 25
            start_y = 100
            for i, line in enumerate(lines):
                if line.strip():
                    line_bbox = draw.textbbox((0, 0), line, font=topic_font)
                    line_w = line_bbox[2] - line_bbox[0]
                    line_pos = (canvas_w // 2 - line_w // 2, start_y + i * line_height)
                    draw.text(line_pos, line, font=topic_font, fill=(0, 0, 0, 204))
            
            bg_img_rgba = bg_img.convert("RGBA")
            final_img = Image.alpha_composite(bg_img_rgba, text_layer)
            self.bg_photo = ImageTk.PhotoImage(final_img)
            self.main_canvas.create_image(0, 0, anchor=tk.NW, image=self.bg_photo)
        else:
            self.main_canvas.create_rectangle(0, 0, canvas_w, canvas_h, fill="#FFE57F", outline="")
            title_label = tk.Label(self.root, text="文本分析工具", font=("Arial", 24, "bold"), bg="#FFE57F", fg="black", relief="flat", padx=10, pady=5)
            self.main_canvas.create_window(canvas_w // 2, 30, window=title_label)
            topic_label = tk.Text(self.root, width=45, height=6, font=("Arial", 14), bg="#FFE57F", fg="black", wrap=tk.WORD, bd=0, relief="flat")
            topic_label.insert(tk.END, "题目：文本分析\n（1）打开txt文件，为诗歌；\n（2）对数据进行统计分析，包括词频分析、词云；\n（3）界面上设计按钮、标签、文本等控件，单击按钮读取文件、显示内容分析")
            topic_label.config(state=tk.DISABLED)
            self.main_canvas.create_window(canvas_w // 2, 150, window=topic_label)

        # 底部按钮
        self.analyze_button = tk.Button(self.root, text="进入分析界面", font=("Arial", 14, "bold"), bg="#4CAF50", fg="white", activebackground="#45a049", padx=20, pady=10, command=self.create_analysis_interface)
        self.main_canvas.create_window(canvas_w // 2, canvas_h - 80, window=self.analyze_button)

        def on_resize(event):
            if event.widget == self.root and hasattr(self, 'analyze_button'):
                self.root.after_idle(self.redraw_main_interface)
        self.root.bind("<Configure>", on_resize)

    def redraw_main_interface(self):
        if not hasattr(self, 'analyze_button') or self.analyze_button.winfo_exists() == 0:
            return
        self.root.update_idletasks()
        canvas_w = self.main_canvas.winfo_width() or self.bg_width
        canvas_h = self.main_canvas.winfo_height() or self.bg_height
        self.main_canvas.delete("all")

        if self.bg_image:
            img_ratio = self.bg_image.width / self.bg_image.height
            canvas_ratio = canvas_w / canvas_h
            if img_ratio > canvas_ratio:
                new_w, new_h = canvas_w, int(canvas_w / img_ratio)
            else:
                new_h, new_w = canvas_h, int(canvas_h * img_ratio)
            if new_w <= 0 or new_h <= 0: new_w, new_h = canvas_w, canvas_h
            
            img_resized = self.bg_image.resize((new_w, new_h), getattr(Image, 'Resampling', Image).LANCZOS if hasattr(Image, 'Resampling') else Image.ANTIALIAS)
            bg_img = Image.new("RGB", (canvas_w, canvas_h), "#FFE57F")
            bg_img.paste(img_resized, (max(0, (canvas_w - new_w) // 2), max(0, (canvas_h - new_h) // 2)))
            
            text_layer = Image.new("RGBA", (canvas_w, canvas_h), (0, 0, 0, 0))
            draw = ImageDraw.Draw(text_layer)
            title_font, topic_font = self.get_chinese_font(24), self.get_chinese_font(16)
            
            title_text = "文本分析工具"
            title_bbox = draw.textbbox((0, 0), title_text, font=title_font)
            draw.text((canvas_w // 2 - (title_bbox[2] - title_bbox[0]) // 2, 30), title_text, font=title_font, fill=(0, 0, 0, 204))
            
            topic_text = "题目：文本分析\n（1）打开txt文件，为诗歌；\n（2）对数据进行统计分析，包括词频分析、词云；\n（3）界面上设计按钮、标签、文本等控件，单击按钮读取文件、显示内容分析"
            for i, line in enumerate(topic_text.split('\n')):
                if line.strip():
                    lb = draw.textbbox((0, 0), line, font=topic_font)
                    draw.text((canvas_w // 2 - (lb[2] - lb[0]) // 2, 100 + i * 25), line, font=topic_font, fill=(0, 0, 0, 204))
            
            self.bg_photo = ImageTk.PhotoImage(Image.alpha_composite(bg_img.convert("RGBA"), text_layer))
            self.main_canvas.create_image(0, 0, anchor=tk.NW, image=self.bg_photo)
        else:
            self.main_canvas.create_rectangle(0, 0, canvas_w, canvas_h, fill="#FFE57F", outline="")
            self.main_canvas.create_window(canvas_w // 2, 30, window=tk.Label(self.root, text="文本分析工具", font=("Arial", 24, "bold"), bg="#FFE57F", fg="black"))
        
        self.main_canvas.create_window(canvas_w // 2, canvas_h - 80, window=self.analyze_button)

    def create_analysis_interface(self):
        for widget in self.root.winfo_children(): widget.destroy()
        self.analysis_frame = ttk.Frame(self.root)
        self.analysis_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        control_frame = ttk.Frame(self.analysis_frame)
        control_frame.pack(fill=tk.X, pady=5)
        ttk.Button(control_frame, text="选择TXT文件", command=self.load_file).pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="开始分析", command=self.perform_analysis).pack(side=tk.LEFT, padx=5)
        ttk.Button(control_frame, text="返回主界面", command=self.return_to_main).pack(side=tk.RIGHT, padx=5)

        self.notebook = ttk.Notebook(self.analysis_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True, pady=5)

        content_frame = ttk.Frame(self.notebook)
        self.notebook.add(content_frame, text="文件内容")
        self.content_text = tk.Text(content_frame, wrap=tk.WORD, font=("Arial", 12))
        ttk.Scrollbar(content_frame, orient=tk.VERTICAL, command=self.content_text.yview).pack(side=tk.RIGHT, fill=tk.Y)
        self.content_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        stats_frame = ttk.Frame(self.notebook)
        self.notebook.add(stats_frame, text="统计分析")
        self.stats_text = tk.Text(stats_frame, wrap=tk.WORD, font=("Arial", 12))
        ttk.Scrollbar(stats_frame, orient=tk.VERTICAL, command=self.stats_text.yview).pack(side=tk.RIGHT, fill=tk.Y)
        self.stats_text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        wordcloud_frame = ttk.Frame(self.notebook)
        self.notebook.add(wordcloud_frame, text="词云")
        self.wordcloud_frame = wordcloud_frame
        self.wordcloud_canvas = None

    def return_to_main(self):
        self.create_main_interface()

    def load_file(self):
        file_path = filedialog.askopenfilename(title="选择TXT文件", filetypes=[("Text files", "*.txt"), ("All files", "*.*")])
        if file_path:
            try:
                with open(file_path, 'r', encoding='utf-8') as f: self.file_content = f.read()
                self.content_text.delete(1.0, tk.END)
                self.content_text.insert(tk.END, self.file_content)
                messagebox.showinfo("成功", f"文件加载成功！共{len(self.file_content)}个字符")
            except UnicodeDecodeError:
                messagebox.showwarning("编码格式错误", "检测到该文件不是UTF-8编码！\n请将文件另存为或转换为 UTF-8 编码后重新打开。")
                self.file_content = ""
                self.content_text.delete(1.0, tk.END)
            except Exception as e:
                messagebox.showerror("错误", f"读取文件失败：{e}")

    def perform_analysis(self):
        if not self.file_content:
            messagebox.showwarning("警告", "请先加载文件")
            return
        self.preprocess_text()
        self.display_statistics()
        self.generate_wordcloud()

    def preprocess_text(self):
        text_cleaned = re.sub(r'[^\w\s]', ' ', self.file_content)
        self.words = jieba.lcut(text_cleaned)
        stop_words = {'的', '了', '在', '是', '我', '有', '和', '就', '不', '人', '都', '一', '一个', '上', '也', '很', '到', '说', '要', '去', '你', '会', '着', '没有', '看', '好', '自己', '这'}
        self.words = [word for word in self.words if len(word) > 1 and word not in stop_words]
        self.chars = [char for char in self.file_content if re.match(r'[\u4e00-\u9fff]', char)]

    def display_statistics(self):
        stats_result = f"总词数: {len(self.words)}\n不重复词数: {len(set(self.words))}\n\n词频统计（前20）:\n"
        for word, freq in Counter(self.words).most_common(20): stats_result += f"{word}: {freq}\n"
        
        stats_result += f"\n总字符数: {len(self.chars)}\n不重复字符数: {len(set(self.chars))}\n\n字符频率统计（前20）:\n"
        for char, freq in Counter(self.chars).most_common(20): stats_result += f"{char}: {freq}\n"
        
        if len(self.chars) > 0:
            try:
                vectorizer = TfidfVectorizer(max_features=10, token_pattern=r'[^\s]', lowercase=False)
                tfidf_matrix = vectorizer.fit_transform([' '.join(self.chars)])
                feature_names = vectorizer.get_feature_names_out()
                scores = sorted(zip(feature_names, tfidf_matrix.toarray()[0]), key=lambda x: x[1], reverse=True)
                stats_result += "\nTF-IDF得分最高的单个字符:\n" + "".join([f"{c}: {s:.4f}\n" for c, s in scores[:10]])
            except ValueError: stats_result += "\nTF-IDF分析: 文档内容不足以进行有效分析\n"
        
        try:
            vectorizer_lda = TfidfVectorizer(max_features=50, token_pattern=r'\b\w{2,}\b', lowercase=False)
            doc_term_matrix = vectorizer_lda.fit_transform([' '.join(self.words)])
            lda_model = LatentDirichletAllocation(n_components=2, random_state=42)
            lda_model.fit(doc_term_matrix)
            stats_result += "\nLDA主题模型结果:\n"
            fn_lda = vectorizer_lda.get_feature_names_out()
            for idx, topic in enumerate(lda_model.components_):
                top_words = [fn_lda[i] for i in topic.argsort()[-10:][::-1]]
                stats_result += f"主题 {idx+1}: {' '.join(top_words)}\n"
        except: stats_result += "\nLDA主题建模失败（可能是文本太短）\n"

        self.stats_text.delete(1.0, tk.END)
        self.stats_text.insert(tk.END, stats_result)

    def generate_wordcloud(self):
        if not self.words: return
        text_for_cloud = ' '.join(self.words)
        plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
        
        wc = None
        for fp in ['C:/Windows/Fonts/simhei.ttf', 'C:/Windows/Fonts/simsun.ttc']:
            try:
                wc = WordCloud(width=800, height=400, background_color='white', font_path=fp, max_words=100, colormap='viridis', min_font_size=10).generate(text_for_cloud)
                break
            except: continue
        if not wc:
            wc = WordCloud(width=800, height=400, background_color='white', max_words=100, colormap='viridis', min_font_size=10).generate(text_for_cloud)

        fig, ax = plt.subplots(figsize=(10, 5))
        ax.imshow(wc, interpolation='bilinear')
        ax.axis('off')
        ax.set_title('词云图', fontsize=16)

        if self.wordcloud_canvas: self.wordcloud_canvas.get_tk_widget().pack_forget()
        self.wordcloud_canvas = FigureCanvasTkAgg(fig, self.wordcloud_frame)
        self.wordcloud_canvas.draw()
        self.wordcloud_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)


if __name__ == "__main__":
    root = tk.Tk()
    app = TextAnalyzerApp(root)
    root.mainloop()
